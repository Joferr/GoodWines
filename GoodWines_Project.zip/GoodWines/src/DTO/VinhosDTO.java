package DTO;

public class VinhosDTO {

    private String namewine, typewine, typegrape, originwine, harmonization, patchimagewine;
    private int idwine, safrawine, starswine;

    public String getNamewine() {
        return namewine;
    }

    public void setNamewine(String namewine) {
        this.namewine = namewine;
    }

    public String getTypewine() {
        return typewine;
    }

    public void setTypewine(String typewine) {
        this.typewine = typewine;
    }

    public String getTypegrape() {
        return typegrape;
    }

    public void setTypegrape(String typegrape) {
        this.typegrape = typegrape;
    }

    public String getOriginwine() {
        return originwine;
    }

    public void setOriginwine(String originwine) {
        this.originwine = originwine;
    }

    public String getHarmonization() {
        return harmonization;
    }

    public void setHarmonization(String harmonization) {
        this.harmonization = harmonization;
    }

    public String getPatchimagewine() {
        return patchimagewine;
    }

    public void setPatchimagewine(String patchimagewine) {
        this.patchimagewine = patchimagewine;
    }

    public int getIdwine() {
        return idwine;
    }

    public void setIdwine(int idwine) {
        this.idwine = idwine;
    }

    public int getSafrawine() {
        return safrawine;
    }

    public void setSafrawine(int safrawine) {
        this.safrawine = safrawine;
    }

    public int getStarswine() {
        return starswine;
    }

    public void setStarswine(int starswine) {
        this.starswine = starswine;
    }

   
}
