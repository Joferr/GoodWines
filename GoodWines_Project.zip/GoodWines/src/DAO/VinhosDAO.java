package DAO;

import DTO.VinhosDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class VinhosDAO {

    Connection conn;        // variável de conexão
    PreparedStatement pstm; // variável que prepara a conexão
    ResultSet rs;           // variável que traz informações do BD conforme query armazenada na variável sql
    ArrayList<VinhosDTO> lista = new ArrayList<>();

    //1. Método Cadastrar
    public Integer salvarVinho(VinhosDTO objvinhosdto) {

        String sql = "insert into wines (namewine, typewine, typegrape, originwine, safrawine, starswine, harmonization, patchimagewine) values (?,?,?,?,?,?,?,?)";
        int key = 0;

        conn = new ConexaoDAO().conectaBD();

        try {

            pstm = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            pstm.setString(1, objvinhosdto.getNamewine());
            pstm.setString(2, objvinhosdto.getTypewine());
            pstm.setString(3, objvinhosdto.getTypegrape());
            pstm.setString(4, objvinhosdto.getOriginwine());
            pstm.setInt(5, objvinhosdto.getSafrawine());
            pstm.setInt(6, objvinhosdto.getStarswine());
            pstm.setString(7, objvinhosdto.getHarmonization());
            pstm.setString(8, objvinhosdto.getPatchimagewine());
            pstm.executeUpdate();

            ResultSet rs = pstm.getGeneratedKeys();
            key = rs.next() ? rs.getInt(1) : 0;
            pstm.close();

            if (key != 0) {
                JOptionPane.showMessageDialog(null, "Vinho salvo com sucesso! ");
            }

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "VinhosDAO_Salvar_Erro Message: " + erro.getMessage());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Salvar_SQLState: " + erro.getSQLState());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Salvar_Error Code: " + erro.getErrorCode());

        }
        return key; // retorna a key = idVinho para a função chamadora

    }

    //2. Método Pesquisar
    public ArrayList<VinhosDTO> pesquisarVinho(String sql) {    // O método pesquisarVinho() é PÚBLICO (é visto em qualquer lugar do código)

        conn = new ConexaoDAO().conectaBD();

        try {
            pstm = conn.prepareStatement(sql);
            rs = pstm.executeQuery();

            while (rs.next()) {
                VinhosDTO objvinhosDTO = new VinhosDTO();
                objvinhosDTO.setIdwine(rs.getInt("idwine"));
                objvinhosDTO.setNamewine(rs.getString("namewine"));
                objvinhosDTO.setTypewine(rs.getString("typewine"));
                objvinhosDTO.setTypegrape(rs.getString("typegrape"));
                objvinhosDTO.setOriginwine(rs.getString("originwine"));
                objvinhosDTO.setSafrawine(rs.getInt("safrawine"));
                objvinhosDTO.setStarswine(rs.getInt("starswine"));
                objvinhosDTO.setHarmonization(rs.getString("harmonization"));
                objvinhosDTO.setPatchimagewine(rs.getString("patchimagewine"));

                lista.add(objvinhosDTO);
            }

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "VinhosDAO_Pesquisar_Erro Message: " + erro.getMessage());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Pesquisar_SQLState: " + erro.getSQLState());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Pesquisar_Error Code: " + erro.getErrorCode());
        }
        return lista;
    }

    //3. Método Alterar
    public void alterarVinho(VinhosDTO objvinhosdto) {
        String sql = "update wines set namewine = ?, typewine = ?, typegrape = ?, originwine = ?, safrawine = ?, starswine = ?, harmonization = ?, patchimagewine = ? where idwine = ?";

        conn = new ConexaoDAO().conectaBD();

        try {

            pstm = conn.prepareStatement(sql);
            pstm.setString(1, objvinhosdto.getNamewine());
            pstm.setString(2, objvinhosdto.getTypewine());
            pstm.setString(3, objvinhosdto.getTypegrape());
            pstm.setString(4, objvinhosdto.getOriginwine());
            pstm.setInt(5, objvinhosdto.getSafrawine());
            pstm.setInt(6, objvinhosdto.getStarswine());
            pstm.setString(7, objvinhosdto.getHarmonization());
            pstm.setString(8, objvinhosdto.getPatchimagewine());
            pstm.setInt(9, objvinhosdto.getIdwine());
            pstm.execute();
            pstm.close();

            //JOptionPane.showMessageDialog(null, "Vinho alterado com sucesso!");

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "VinhosDAO_Alterar_Erro Message: " + erro.getMessage());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Alterar_SQLState: " + erro.getSQLState());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Alterar_Error Code: " + erro.getErrorCode());

        }
    }

    //3. Método Excluir    
    public void excluirVinho(VinhosDTO objvinhosdto) {
        String sql = "delete from wines where idwine = ?";

        conn = new ConexaoDAO().conectaBD();

        try {

            pstm = conn.prepareStatement(sql);
            pstm.setInt(1, objvinhosdto.getIdwine());
            pstm.execute();
            pstm.close();

            JOptionPane.showMessageDialog(null, "Vinho excluído com sucesso!");

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "VinhosDAO_Excluir_Erro Message: " + erro.getMessage());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Excluir_SQLState: " + erro.getSQLState());
            JOptionPane.showMessageDialog(null, "VinhosDAO_Excluir_Error Code: " + erro.getErrorCode());
        }
    }

} // fecha public class VinhosDAO
