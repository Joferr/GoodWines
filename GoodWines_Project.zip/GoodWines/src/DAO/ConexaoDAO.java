package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexaoDAO {

    public Connection conectaBD() {

        Connection conn = null;

        try {

            String url = "jdbc:mysql://localhost:3306/goodwines_bd?useTimezonetrue&serverTimezone=UTC";
            conn = DriverManager.getConnection(url, "root", "root");

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Conexao_BD_Error Message: " + erro.getMessage());
            JOptionPane.showMessageDialog(null, "Conexao_BD_SQLState: " + erro.getSQLState());
            JOptionPane.showMessageDialog(null, "Conexao_BD_Error Code: " + erro.getErrorCode());
        }
        return conn;

    }

}
